<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SellInvoiceDetails extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sell_invoice_details', function (Blueprint $table) {
            $table->increments('id');
            $table->string    ('sid_invoice_id');
            $table->integer   ('sid_product_id');
            $table->integer   ('sid_qty');
            $table->float     ( 'sid_Unit_price');
            $table->float     ( 'sid_EPL_price');
            $table->integer   ('deleted_flag');
            $table->integer   ('archive_flag');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('sell_stockrequests_detail');
    }
}
