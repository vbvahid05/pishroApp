<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SellInvoice extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sell_invoices', function (Blueprint $table) {
            $table->increments('id');
            $table->string    ('si_Alias_id')->nullable();
            $table->string    ('si_Currency');
            $table->integer   ('si_custommer_id');
            $table->string    ('si_date');

            $table->string    ('si_Discount');
            $table->string    ('si_warranty');
            $table->string    ('si_Payment');
            $table->string    ('si_deliveryDate');
            $table->string    ('si_Description');

            $table->integer   ('deleted_flag');
            $table->integer   ('archive_flag');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('sell_invoices');
    }
}
