

<div id="copyright text-right">
    {{ Lang::get('labels.copyright') }}
    {{ Lang::get('labels.copyright_date') }}



</div>
